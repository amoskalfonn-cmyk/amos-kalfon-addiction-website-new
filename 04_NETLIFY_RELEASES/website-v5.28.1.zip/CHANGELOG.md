# Changelog

## v5.28.1 - 2026-07-17

### Added
- Added an isolated RTL process timeline section to `services/treatment-guidance.html` explaining how the guidance process works.

### Changed
- No SEO metadata, schema, navigation, CTA sections, existing content blocks, JavaScript, links, or global styling were changed.

### Fixed
- No defect fixes were included; this sprint only adds the approved isolated trust-building section.

## v5.28.0 - 2026-07-17

### Added
- Added a premium service page for treatment guidance and referral: `services/treatment-guidance.html`.
- Added SEO metadata, Open Graph metadata, canonical URL, breadcrumb schema, Service schema and FAQ schema for the new page.
- Added an internal discovery link from `specialties.html` to the new service page.
- Added the new service page to `sitemap.xml`.

### Changed
- No global design, navigation, JavaScript, form behavior or existing WhatsApp/contact URLs were changed.

### Fixed
- Prevented the new service page from becoming orphaned by linking it from the existing specialties page.
