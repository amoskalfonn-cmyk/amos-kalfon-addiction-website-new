# Project Roadmap

## Completed

### Sprint 2A.1 - Guidance Process Timeline
- Completed an isolated premium RTL timeline section on the treatment guidance page.
- Preserved the locked Sprint 2A page content, CTAs, SEO, schema, navigation and functionality.

### Sprint 2A - Services & Conversion: Treatment Guidance & Referral
- Created a dedicated premium service page for treatment guidance and referral.
- Clarified service boundaries: guidance only, no diagnosis, no treatment guarantees and no replacement for licensed medical or therapeutic assessment.
- Added FAQ, structured data, internal links and sitemap coverage.

## Recommended Next Sprints

1. Expand service-level internal linking from relevant knowledge pages such as families, recovery, alcohol, drugs and gambling.
2. Add a short decision checklist section to `articles/how-to-choose-addiction-help` that links naturally to the new service page.
3. Build a trust-focused referral explainer for families: what to ask a treatment provider before enrolling.
4. Add conversion measurement QA for contact-form submissions and WhatsApp click events if analytics is configured.
5. Consider adding a future short checklist PDF or printable guide for families comparing treatment options, only after content approval.

